package com.sunita;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.sunita.user.User;
import com.sunita.user.UserRepository;

@Configuration
public class DataLoader {
	@Bean
	public CommandLineRunner loadData(UserRepository userRepo)  {
		return r-> {
			userRepo.save(new User("1","sunita@gmail.com","sunita"));
			};
		
	}
	

}
