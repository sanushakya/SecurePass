package com.sunita;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManagePasswordApplication {

	public static void main(String[] args) {
		SpringApplication.run(ManagePasswordApplication.class, args);
	}

}
