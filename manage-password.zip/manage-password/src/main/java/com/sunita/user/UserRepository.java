package com.sunita.user;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

public interface UserRepository extends CrudRepository<User, String> {
	
	//public List<Course> findByName(String name);
	//public List<Course> findByDescription(String description);
	
	//public List<User> findByTopicId(String topicId);
	
}
